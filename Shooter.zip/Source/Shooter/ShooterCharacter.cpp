// Fill out your copyright notice in the Description page of Project Settings.


#include "ShooterCharacter.h"
#include "Gun.h"
#include "Components/CapsuleComponent.h"
#include "SimpleShooterGameModeBase.h"
#include "Shooter/W_PauseMenu.h"
#include "Kismet/GameplayStatics.h"

// Sets default values
AShooterCharacter::AShooterCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AShooterCharacter::BeginPlay()
{
	Super::BeginPlay();

	//TSubclassOf<AGun> DefaultGunClass = AvailableGunClasses.Num() > 0 ? AvailableGunClasses[0] : nullptr;
	
	Gun = GetWorld()->SpawnActor<AGun>(GunClass);
	GetMesh()->HideBoneByName(TEXT("weapon_r"),EPhysBodyOp::PBO_None);
	Gun->AttachToComponent(GetMesh(), FAttachmentTransformRules::KeepRelativeTransform,TEXT("WeaponSocket"));
	Gun->SetOwner(this);

	CurrentWeaponIndex = 0;

	Health=MaxHealth;

	PauseMenu = CreateWidget<UW_PauseMenu>(GetWorld(), PauseMenuWidgetClass);
    if (PauseMenu)
    {
		UE_LOG(LogTemp, Display, TEXT("Pause Menu"));
        PauseMenu->AddToViewport();
        PauseMenu->SetVisibility(ESlateVisibility::Hidden); // Hide the widget initially
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("Failed to create PauseMenu widget"));
    }
}

// Called every frame
void AShooterCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// Get the current location and rotation of the character
    FVector CharacterLocation = GetActorLocation();
    FRotator CharacterRotation = GetActorRotation();

    // Log the location and rotation
    UE_LOG(LogTemp, Warning, TEXT("Character Location: %s"), *CharacterLocation.ToString());
    UE_LOG(LogTemp, Warning, TEXT("Character Rotation: %s"), *CharacterRotation.ToString());
}

// Called to bind functionality to input
void AShooterCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	PlayerInputComponent->BindAxis(TEXT("MoveForward"),this, &AShooterCharacter::MoveForward);
	PlayerInputComponent->BindAxis(TEXT("LookUp"),this, &APawn::AddControllerPitchInput);
	PlayerInputComponent->BindAxis(TEXT("MoveRight"), this, &AShooterCharacter::MoveRight);
	PlayerInputComponent->BindAxis(TEXT("LookRight"), this, &APawn::AddControllerYawInput);
	PlayerInputComponent->BindAction(TEXT("Jump"), EInputEvent::IE_Pressed, this, &ACharacter::Jump);
	//PlayerInputComponent->BindAxis(TEXT("LookUp"), this, &AShooterCharacter::LookUp); This is also another way to create the above LookUp setup
	PlayerInputComponent->BindAxis(TEXT("LookUpRate"),this,&AShooterCharacter::LookUpRate);
	PlayerInputComponent->BindAxis(TEXT("LookRightRate"),this,&AShooterCharacter::LookRightRate);
	PlayerInputComponent->BindAction(TEXT("Shoot"),EInputEvent::IE_Pressed, this,&AShooterCharacter::Shoot);
	PlayerInputComponent->BindAction(TEXT("Reload"), EInputEvent::IE_Pressed, this, &AShooterCharacter::Reload);
	PlayerInputComponent->BindAction(TEXT("SwitchWeapon"),EInputEvent::IE_Pressed, this, &AShooterCharacter::SwitchWeapon);
	PlayerInputComponent->BindAction(TEXT("Pause"),EInputEvent::IE_Pressed, this, &AShooterCharacter::TogglePause);
	UE_LOG(LogTemp, Warning, TEXT("Pause key is bound."));
}

float AShooterCharacter::TakeDamage(float DamageAmount, struct FDamageEvent const &DamageEvent, class AController* EventInstigator, AActor* DamageCauser)
{
	float DamageToApply = Super::TakeDamage(DamageAmount, DamageEvent, EventInstigator, DamageCauser);
	DamageToApply = FMath::Min(Health,DamageToApply);
	Health = Health - DamageToApply;
	//UE_LOG(LogTemp, Display, TEXT("Health Remaining %f"), Health);

	if (IsDead())
	{
		ASimpleShooterGameModeBase* GameMode = GetWorld()->GetAuthGameMode<ASimpleShooterGameModeBase>();
		if (GameMode != nullptr)
		{
			GameMode->PawnKilled(this);
		}
		DetachFromControllerPendingDestroy();
		GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		
		
	}
	return DamageToApply;
}

void AShooterCharacter::MoveForward(float AxisValue)
{
	AddMovementInput(GetActorForwardVector()*AxisValue);
}

bool AShooterCharacter::IsDead() const
{
	return Health<=0;
}

//void AShooterCharacter::LookUp(float AxisValue)
//{
//	AddControllerPitchInput(AxisValue);
//}
void AShooterCharacter::MoveRight(float AxisValue)
{
	AddMovementInput(GetActorRightVector()*AxisValue);
}
//void AShooterCharacter::LookRight(float AxisValue);
//{
//	AddControllerYawInput(AxisValue);
//}
void AShooterCharacter::LookUpRate(float AxisValue)
{
	AddControllerPitchInput(AxisValue*RotationRate*GetWorld()->GetDeltaSeconds());
}
void AShooterCharacter::LookRightRate(float AxisValue)
{
	AddControllerYawInput(AxisValue*RotationRate*GetWorld()->GetDeltaSeconds());
}

void AShooterCharacter::Shoot()
{
	Gun->PullTrigger();
}
float AShooterCharacter::GetHealthPercent() const
{
	return Health/MaxHealth;
}
void AShooterCharacter::Reload()
{
	if (Gun)
	{
		//int32 AmmoToReload = 10;
		Gun->ReloadAmmo();
	}
}
//New code
void AShooterCharacter::SwitchWeapon()
{
	CurrentWeaponIndex = (CurrentWeaponIndex + 1) % AvailableGunClasses.Num();
	//SwitchWeapon();
	if (AvailableGunClasses.IsValidIndex(CurrentWeaponIndex))
    {
        TSubclassOf<AGun> NewGunClass = AvailableGunClasses[CurrentWeaponIndex];
        AGun* NewGun = GetWorld()->SpawnActor<AGun>(NewGunClass);
        NewGun->AttachToComponent(GetMesh(), FAttachmentTransformRules::KeepRelativeTransform, TEXT("WeaponSocket"));
        NewGun->SetOwner(this);

        if (Gun)
        {
            Gun->DetachFromActor(FDetachmentTransformRules::KeepRelativeTransform);
        }

        // Set the new weapon class as the current weapon class
        GunClass = NewGunClass;
        Gun = NewGun;
    }
	
}
void AShooterCharacter::TogglePause()
{
	
	bool bIsGamePaused = UGameplayStatics::IsGamePaused(GetWorld());	
	if (bIsGamePaused)
	//if (UGameplayStatics::IsGamePaused(GetWorld()))
	{
		UGameplayStatics::SetGamePaused(GetWorld(),true);
		if (PauseMenu)
		{
			PauseMenu->RemoveFromParent();
            UE_LOG(LogTemp, Warning, TEXT("Game was paused and is now resumed"));
		}
	}
	else
	{
		UGameplayStatics::SetGamePaused(GetWorld(), true); // Pause the game
        PauseMenu = CreateWidget<UW_PauseMenu>(GetWorld(), PauseMenuWidgetClass);
        if (PauseMenu)
        {
            PauseMenu->AddToViewport();
            UE_LOG(LogTemp, Warning, TEXT("Game is paused"));
		}
	}
}
//Ends Here